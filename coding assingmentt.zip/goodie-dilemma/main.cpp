#include<iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <vector>

using namespace std;




int main()

{

                ifstream file ("sample_input.txt") ; 
                
                if(!file.is_open()){
                   cout<<"file not open"<<endl ; 
                   return 0 ; 
                }
                
                
              
                string text,number,goodie ; 
                int cost ; 


                vector<string> texts ; 

                vector< pair <int , string> > vect;

                vector<int> costs ; 
                string line ; 
                int i = 0 ; 



                 int no_employers ; 

                getline(file , line) ;
                
                stringstream ss(line) ; 
                getline(ss,text , ':') ; 
                getline(ss,number , ':') ;
                no_employers = stoi(number) ;
                cout<<no_employers<<endl;





                while(getline(file , line)    ){

                    if(i>2) {


                
                     stringstream ss(line) ; 
                     getline(ss,goodie , ':') ; 
                     getline(ss,number ) ;
                     cost = stoi(number) ; 

                     texts.push_back(goodie) ; 
                     costs .push_back(cost) ; 


                     vect.push_back(make_pair(cost,goodie)) ; 





                 }
                 i++ ; 

                
                }




                sort(vect.begin(), vect.end()) ;


                  int min = 999999999 ; 
                  int start,end ; 

               for(int  i = 0 ; i+no_employers < vect.size() ; i++) {


                if( (vect[i+no_employers-1].first - vect[i].first) < min ){

                    start = i ; 
                    end  = i+ no_employers - 1 ; 

                    min = vect[i+no_employers-1].first - vect[i].first ;
                }

               } 


               for (int i=start; i<= end; i++)
                    {
                        
                        cout << vect[i].first << " "
                             << vect[i].second << endl;
                 
                    }









              ofstream fw("Output.txt", ofstream::out); 
              

              if (fw.is_open())
              {

                fw<< "The goodies selected for distribution are:"<<endl ; 
                fw<<" "<< endl ;

                //store array contents to text file
                for (int i = start; i <= end; i++) {
                  fw <<   vect[i].second<< ": " << vect[i].first << "\n";
                }

                fw<<" "<< endl ;

                fw<<"And the difference between the chosen goodie with highest price and the lowest price is " << min ; 

                fw.close();
              }
              else cout << "Problem with opening file";
      




}


